<!-- post-nav -->
<div class="post-nav clearfix"> 
	<?php previous_post_link( '<span class="prev">%link</span>', '<span class="arrow">' . _x( '&laquo;', 'Previous entry link arrow','themify') . '</span> %title' ) ?>
	<?php next_post_link('<span class="next">%link</span>', '%title <span class="arrow">&raquo;</span>') ?>
</div>
<!-- /post-nav -->